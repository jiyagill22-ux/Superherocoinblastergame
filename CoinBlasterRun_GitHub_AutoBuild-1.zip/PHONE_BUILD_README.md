# Phone-only build

Upload the CONTENTS of this folder to a GitHub repository (not this ZIP itself).

Then:
1. Open Actions.
2. Select "Build Coin Blaster Run".
3. Tap "Run workflow".
4. After it finishes, download the APK artifact for testing.
5. Download the AAB artifact for Play Console.

For Play Store production, the release AAB must be properly signed with your own keystore. Keep the keystore and password backed up for future updates.
