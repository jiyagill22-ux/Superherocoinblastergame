# Coin Blaster Run — Android Studio Project

This project wraps the supplied HTML game in an Android WebView.

## Build
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Generate Signed App Bundle / APK.
4. Choose Android App Bundle (.aab) for Google Play.
5. Use package name: com.superhero.coinblasterrun

The game HTML is in `app/src/main/assets/game.html`.
